# UniPlan5 → UniPlan Simple

## Kept

- ProblemData, Candidate, Evaluation, Evaluator/DefaultEvaluator, Objectives, SearchEngine and interval-based ConstraintSearch.
- Independent feasibility/objective verification, seeded Random and Exhaustive baselines, CP-SAT, JSON persistence pattern and autosave.
- Week grid, filters, printable HTML, CSV and a single green palette.
- All eight existing JUnit tests, with new Simple-specific tests added. CLI experiments remain available.

## Removed from the product UI

- Semester dates/holidays/exam ranges and ICS.
- Workloads, preferred days, weights, raw tables and lock/rule editors.
- GA/Hybrid choices and parameter fields; experiment charts/tables.
- Multiple-semester portfolio switching, alternative timetables and manual drag/drop.
- Old Studio/Setup/RecordForm/TermEditor/ObjectiveEditor frontend classes and its old smoke harness. CalendarExport and legacy JSON/model helpers remain only because the retained tests/developer tools exercise them.

## Added

- Seven-screen SimpleApp with left stepper, typed labeled controls, inline errors, tooltips and editing dialogs.
- Fixed stages 1–4, editable group lists, per-group subjects with independent enrollment/session count/duration and optional instructor.
- Independent daily start/end/class length/breaks, copy action, live green/grey preview.
- SimpleProject adapter/document schema 1, explicit validation and fixed gap/balance weights.
- Friendly health report with linked fixes, CP default, 20-second limit, responsive progress and Cancel.
- 4-stage/8-group demo with 56 sessions, 10 classrooms and 4 labs.
- Subject IDs independent of names, unique internal placeholders for blank instructors, no false collision between all unassigned teachers.
- Screenshots, real test/launch logs, data dictionary, research/credits and a three-minute explanation.

## Bugs fixed

- JavaFX 21.0.2's duplicate Maven profile IDs generated six warnings: upgraded the existing JavaFX dependency to 21.0.9.
- JavaFX Maven plugin 0.0.8 drops OR-Tools native JARs with invalid automatic module names in non-modular projects. Its includePathExceptions setting does not fix that branch. Native resources now unpack from the same pinned OR-Tools version during process-resources, for the selected OS only; they are not put through module-name inference.
- OR-Tools 9.11's built-in loader assumes a jar resource URI; it cannot unpack a plain classes-directory URI. The small NativeSolver adapter loads the JNI library directly for file resources, and delegates to the original loader for jar resources. No search algorithm was rewritten.
- HTML used stale navy colors and called a weighted score “gap minutes.” It now derives colors from studio.css and labels the weighted objective correctly.
- Simple mode adds fixed blocked intervals for breaks/remainders to each existing resource NoOverlap constraint. Legacy policies with post-class rest retain their original domain semantics, so those tests continue to pass.
- Error handling now logs the actual cause of a failed background task, including native initialization errors, instead of showing only “null.”

## Intentional choices

Daily class length defines full teaching periods; subject duration can be shorter but cannot cross periods. Short remainders are unavailable. New subjects default to the first selected day's class length. Exact semantics are shown in the UI and README.

The new JSON schema does not silently import advanced UniPlan5 settings. The old reader remains in the code for legacy tests/tools. Four-stage Simple inputs and legacy UniPlan5 inputs remain separate documents.

## Hybrid update (2026-11-21)
- Restored the later Simple features onto the supplied older ZIP without changing the protected domain/evaluator files, weights, schema version or dependencies.
- Fixed Generate time-limit clipping with a separate 180-pixel row and visible horizontal arrows; kept editable spinners and validation.
- Added deterministic Random(2026) demo enrollment: 8 groups, 40 subjects, 64 sessions; Theory 25-55 and Lab 15-30 students.
- Added Randomize students, explicit startup choices, three rolling autosave backups and dated recovery choices.
- Added Hybrid (CP + GA): greedy population, tournament/crossover/mutation, CP repairs, three neighbourhood choices, periodic global hints and adaptive phase allocation.
- Added Advanced Generations per GA phase (default 5) and live phase/improvement counters.
- Fixed numeric error clearing, editable hour/minute controls and automatic timetable scrolling.
- Added CompareMethods and demo-fixture, backup and Hybrid regression coverage; all 33 tests passed.
- Captured both window sizes, cancellation, restore/recovery, filters, exports and a finished 64-session Hybrid run in the UI smoke.
- Thirty-second default-worker medians: CP 8640, GA 9900, Hybrid 8730; CP remains the default because Hybrid did not win.
- Real outputs are in results/final-tests.txt, final-smoke.txt and compare-methods.txt; headless shutdown emitted nonfatal CSS warnings.
- Windows and large-scale scheduling were not verified; parallel-worker timings and scores may vary.
