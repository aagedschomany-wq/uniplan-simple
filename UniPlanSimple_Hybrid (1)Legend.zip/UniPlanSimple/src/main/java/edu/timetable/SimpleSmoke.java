package edu.timetable;
import javafx.application.Platform;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.layout.Region;
import javafx.stage.Window;
import javafx.event.ActionEvent;
import java.nio.file.*;
import java.util.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
/** Opt-in UI integration harness; runs against an isolated user.home. */
final class SimpleSmoke {
    static long started;static boolean finished;
    static void require(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    static void later(int milliseconds,Runnable work){var pause=new PauseTransition(Duration.millis(milliseconds));pause.setOnFinished(e->{try{work.run();}catch(Throwable ex){fail(ex);}});pause.play();}
    static void clickDialog(String text){later(120,()->{for(var window:new ArrayList<>(Window.getWindows()))if(window.isShowing()){var node=window.getScene().getRoot().lookup(".dialog-pane");if(node instanceof DialogPane pane)for(var type:pane.getButtonTypes())if(type.getText().equals(text)){((Button)pane.lookupButton(type)).fire();return;}}throw new AssertionError("Dialog button not found: "+text);});}
    static void run(SimpleApp app){
        try{
            Files.createDirectories(Path.of("results"));require(app.limit.value()==60,"Default limit must be 60");
            // The automatic startup dialog is bypassed only in smoke mode; exercise it here.
            clickDialog("Start with demo data");app.startupChoice();app.autosave.stop();app.dirty=false;require(app.project.subjects.size()==40,"Startup demo");
            app.project.department="Saved smoke work";app.project.save(app.recovery);clickDialog("Restore");app.startupChoice();app.autosave.stop();app.dirty=false;require(app.project.department.equals("Saved smoke work"),"Startup restore");
            app.loadDemo();app.autosave.stop();app.dirty=false;var counts=app.project.subjects.stream().map(SimpleProject.Subject::students).toList();app.randomizeStudents();app.autosave.stop();app.dirty=false;require(app.project.health().stream().noneMatch(SimpleProject.Issue::error),"Randomized counts must fit");require(!counts.equals(app.project.subjects.stream().map(SimpleProject.Subject::students).toList()),"Randomize button");
            clickDialog("OK");app.recoverAutosave();app.autosave.stop();app.dirty=false;require(SimpleProject.recoveryCopies(app.recovery).size()==4,"Current autosave and three backups");app.loadDemo();app.autosave.stop();app.dirty=false;require(app.status.getText().equals("Demo loaded: 8 groups, 40 subjects, 64 sessions, students 15-55"),"Demo feedback");
            System.out.println("PASS startup choices, Restore, rolling backups, recovery list, randomized counts and canonical demo");
            var field=SimpleFields.number("Time limit (seconds)",60,1,300);var spinner=(Spinner<Integer>)field.input;spinner.getEditor().setText("999");spinner.getEditor().fireEvent(new ActionEvent());require(field.value()==60,"Invalid number reverts");spinner.getEditor().setText("65");spinner.getEditor().fireEvent(new ActionEvent());require(field.value()==65&&!field.error.isVisible(),"Valid number clears red message");
            var time=new SimpleFields.Time("Smoke time",540);time.hours.getEditor().setText("10");time.hours.getEditor().fireEvent(new ActionEvent());require(time.value()==600,"Editable hour");time.hours.getEditor().setText("24");time.hours.getEditor().fireEvent(new ActionEvent());require(time.value()==600,"Hour range");time.minutes.getEditor().setText("59");time.minutes.getEditor().fireEvent(new ActionEvent());require(time.value()==659,"Editable minute");time.minutes.getEditor().setText("60");time.minutes.getEditor().fireEvent(new ActionEvent());require(time.value()==659,"Minute range");
            for(int i=0;i<7;i++){app.step=i;app.render();if(i<6)require(app.validatePage(),"Wizard page "+i+": "+app.pageError.getText());}System.out.println("PASS seven wizard screens and numeric/time editing");
            app.stage.setWidth(1420);app.stage.setHeight(960);later(200,()->{arrows(app);snapshot(app,"generate-arrows.png");app.stage.setWidth(1050);app.stage.setHeight(740);later(200,()->{arrows(app);snapshot(app,"generate-arrows-min.png");app.stage.setWidth(1420);app.stage.setHeight(960);later(200,()->startSearch(app));});});
        }catch(Throwable ex){fail(ex);}
    }
    static void arrows(SimpleApp app){app.root.applyCss();app.root.layout();var spinner=(Spinner<?>)app.limit.input;require(spinner.getWidth()>=180,"Spinner squeezed");require(spinner.getStyleClass().contains(Spinner.STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL),"Horizontal arrows");for(String selector:List.of(".increment-arrow-button",".decrement-arrow-button")){var button=(Region)spinner.lookup(selector);require(button!=null&&button.getWidth()>0&&button.getMinWidth()==34,"Arrow style");}System.out.println("PASS arrows at "+app.stage.getWidth()+"x"+app.stage.getHeight()+" width="+spinner.getWidth());}
    static void startSearch(SimpleApp app){((ComboBox<String>)app.method.input).setValue(SearchEngine.HYBRID);((Spinner<Integer>)app.limit.input).getValueFactory().setValue(8);app.generate();later(250,()->{((Button)app.root.lookup("#cancel")).fire();afterCancel(app,0);});}
    static void afterCancel(SimpleApp app,int checks){later(100,()->{if(app.busy){require(checks<50,"Cancellation timeout");afterCancel(app,checks+1);return;}require(app.runStatus.getText().startsWith("Cancelled"),"Cancel feedback");System.out.println("PASS Cancel button and responsive controls");started=System.nanoTime();app.generate();poll(app);});}
    static void poll(SimpleApp app){later(100,()->{
        if(app.busy){require((System.nanoTime()-started)/1e9<25,"Hybrid smoke timeout");poll(app);return;}
        require(app.result!=null&&app.result.best!=null,"No feasible Hybrid demo: "+app.runStatus.getText());var score=Evaluator.evaluate(app.result.m,app.result.best);require(score.valid(),"Hard violations: "+score.violations());require(app.result.m.events.size()==64,"Expected 64 sessions");require(app.result.score<=app.result.bestGreedySeed,"Hybrid lost its best seed");
        snapshot(app,"hybrid-finished.png");app.stageFilter.setValue("Stage 4");require(app.visibleRows.size()==16,"Stage filter");app.groupFilter.setValue("4 A");require(app.visibleRows.size()==8,"Group filter");
        try{SimpleExport.csv(Path.of("results/demo-stage4-A.csv"),app.visibleRows);String teacher=app.visibleRows.getFirst()[4];app.teacherFilter.setValue(teacher);require(!app.visibleRows.isEmpty()&&app.visibleRows.stream().allMatch(r->r[4].equals(teacher)),"Instructor filter");String room=app.visibleRows.getFirst()[6];app.roomFilter.setValue(room);require(!app.visibleRows.isEmpty()&&app.visibleRows.stream().allMatch(r->r[6].equals(room)),"Room filter");SheetExport.save(app.result.m.data,app.result,Path.of("results/demo-timetable.html"));app.project.save(Path.of("results/smoke-project.json"));require(SimpleProject.load(Path.of("results/smoke-project.json")).restoreResult()!=null,"Hybrid JSON restore");
            String result=String.format(Locale.ROOT,"PASS Hybrid smoke: 64 sessions, status=%s, score=%d, hard=%d, seconds=%.3f, rounds=%d, GA improvements=%d, CP improvements=%d%nPASS filters, canonical demo, recovery, numeric inputs, independent evaluation and exports%n",app.result.status,app.result.score,score.violations().size(),(System.nanoTime()-started)/1e9,app.result.rounds,app.result.gaImprovements,app.result.cpImprovements);Files.writeString(Path.of("results/final-smoke-summary.txt"),result);System.out.print(result);
        }catch(Exception ex){throw new RuntimeException(ex);}finished=true;app.autosave.stop();app.dirty=false;app.stage.close();Platform.exit();
    });}
    static void snapshot(SimpleApp app,String name){try{app.root.applyCss();app.root.layout();var im=app.stage.getScene().snapshot(null);var image=new BufferedImage((int)im.getWidth(),(int)im.getHeight(),BufferedImage.TYPE_INT_ARGB);for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++)image.setRGB(x,y,im.getPixelReader().getArgb(x,y));ImageIO.write(image,"png",Path.of("results",name).toFile());}catch(Exception ex){throw new RuntimeException(ex);}}
    static void fail(Throwable ex){ex.printStackTrace();Platform.exit();System.exit(1);}
}
