package edu.timetable;
import java.util.*;
import java.util.function.*;
class SearchEngine implements SearchMethod {
    static final org.slf4j.Logger LOG=org.slf4j.LoggerFactory.getLogger(SearchEngine.class);
    record Settings(int seed,double seconds,int population,int generations,double mutation,long samples){
        Settings{ProblemData.require(seconds>0&&Double.isFinite(seconds)&&population>=2&&generations>0&&mutation>=0&&mutation<=1&&samples>0,"Invalid search settings");}
    }
    interface ConstraintSolver {int[] solve(SearchEngine run,int[] child,boolean optimize,double seconds);}
    final ProblemData m;final Settings settings;final Random rng;final BooleanSupplier cancelled;final long start;
    long evaluations,mutations,nodes,attempts;
    boolean feasibleGenerator=true,warmStart=true,reportDiagnostics=true;
    int workers=Math.min(8,Runtime.getRuntime().availableProcessors());
    static final String HYBRID="Hybrid (CP + GA)";
    int gaPhaseGenerations=5,bestGreedySeed=Integer.MAX_VALUE;boolean[] neighbourhood;
    volatile String phase="Seeding";volatile long rounds,gaImprovements,cpImprovements;
    int[] hint;volatile int[] best;volatile int score=Integer.MAX_VALUE;String status="Budget ended";boolean proved;
    final List<double[]> trace=new ArrayList<>();
    SearchEngine(ProblemData model,Settings options,BooleanSupplier cancel){m=model;settings=options;rng=new Random(options.seed);cancelled=cancel;start=System.nanoTime();}
    double elapsed(){return (System.nanoTime()-start)/1e9;}
    double left(){return settings.seconds-elapsed();}
    boolean stop(){return left()<=0||cancelled.getAsBoolean();}
    int inspect(int[] genes){
        evaluations++;var result=new DefaultEvaluator().evaluate(m,new Candidate(genes));
        if(!result.feasible())return Integer.MAX_VALUE;
        if(result.objective()<score){if(phase.startsWith("GA"))gaImprovements++;else if(phase.startsWith("CP"))cpImprovements++;best=genes.clone();score=result.objective();trace.add(new double[]{evaluations,score,elapsed()});}
        return result.objective();
    }
    int[] sample(){int[] genes=new int[m.events.size()];for(int i=0;i<genes.length;i++)genes[i]=rng.nextInt(m.choices.get(i).size());return genes;}
    public void run(String method,ConstraintSolver cp){
        LOG.debug("Starting {} seed={} budget={}",method,settings.seed,settings.seconds);
        for(int i=0;i<m.events.size();i++)if(m.choices.get(i).isEmpty()){
            var e=m.events.get(i);status="INFEASIBLE: "+m.diagnostics.get(i);return;}
        if(reportDiagnostics)diagnostics();
        switch(method){
            case "Random"->{while(!stop()&&attempts<settings.samples){attempts++;int[] candidate=feasibleGenerator?greedySeed():sample();if(candidate!=null)inspect(candidate);}}
            case "Exhaustive"->{int[] genes=new int[m.events.size()];Arrays.fill(genes,-1);Integer[] order=new Integer[genes.length];for(int i=0;i<order.length;i++)order[i]=i;Arrays.sort(order,Comparator.comparingInt(i->m.choices.get(i).size()));proved=enumerate(genes,order,0);}
            case "CP"->{if(warmStart){double until=elapsed()+Math.max(0,left()*.10);while(!stop()&&elapsed()<until){int[] seed=greedySeed();if(seed!=null)inspect(seed);}hint=best==null?null:best.clone();}phase="CP solve";int[] result=cp.solve(this,null,true,left());if(result!=null)inspect(result);}
            case "GA"->evolve(cp);
            case "Hybrid",HYBRID->evolve(cp,true);
            default->throw new IllegalArgumentException(method);
        }
        if(cancelled.getAsBoolean())status="Cancelled";
        else if(best!=null)status=proved||(!method.equals("Exhaustive")&&score==0)?"OPTIMAL":"FEASIBLE";
        else if(proved)status="INFEASIBLE";
        else status="UNKNOWN";
        LOG.debug("Finished {} status={} score={} seconds={}",method,status,score,elapsed());
        if(method.equals(HYBRID)||method.equals("Hybrid"))System.out.printf(Locale.ROOT,"Hybrid seed=%d workers=%d rounds=%d GA_improvements=%d CP_improvements=%d best=%s seconds=%.3f%n",settings.seed(),workers,rounds,gaImprovements,cpImprovements,best==null?"UNKNOWN":score,elapsed());
    }
    double searchSpaceLog10(){return m.choices.stream().mapToDouble(c->c.isEmpty()?Double.NEGATIVE_INFINITY:Math.log10(c.size())).sum();}
    void diagnostics(){
        var random=new Random(settings.seed());int feasible=0;
        for(int sample=0;sample<2000;sample++){int[] genes=new int[m.events.size()];for(int i=0;i<genes.length;i++)genes[i]=random.nextInt(m.choices.get(i).size());if(Evaluator.evaluate(m,genes).valid())feasible++;}
        System.out.printf(Locale.ROOT,"Search space: 10^%.3f; uniform feasible: %d/2000 (%.4f%%)%n",searchSpaceLog10(),feasible,feasible/20.0);
    }
    boolean enumerate(int[] genes,Integer[] order,int depth){
        if(stop())return false;
        if(depth==order.length){inspect(genes);return true;}
        int event=order[depth];
        for(int k=0;k<m.choices.get(event).size();k++){
            if(stop())return false;nodes++;boolean fits=true;
            for(int j=0;j<depth;j++){int previous=order[j];if(m.conflict(event,m.choices.get(event).get(k),previous,m.choices.get(previous).get(genes[previous]))!=null){fits=false;break;}}
            if(!fits)continue;genes[event]=k;
            if(!enumerate(genes,order,depth+1)){genes[event]=-1;return false;}
            genes[event]=-1;
        }
        return true;
    }
    record Member(int[] genes,int cost){}
    Member tournament(List<Member> population){
        Member winner=population.get(rng.nextInt(population.size()));
        for(int i=1;i<3;i++){Member rival=population.get(rng.nextInt(population.size()));if(rival.cost<winner.cost)winner=rival;}
        return winner;
    }
    int[] crossover(Member a,Member b){int[] child=a.genes.clone();for(int i=0;i<child.length;i++)if(rng.nextBoolean())child[i]=b.genes[i];return child;}
    void mutate(int[] child){
        for(int i=0;i<child.length;i++)if(rng.nextDouble()<settings.mutation){
            int size=m.choices.get(i).size();if(size<2)continue;
            int replacement=rng.nextInt(size-1);if(replacement>=child[i])replacement++;
            child[i]=replacement;mutations++;
        }
    }
    int[] greedySeed(){
        int[] genes=new int[m.events.size()];Arrays.fill(genes,-1);
        var order=new ArrayList<Integer>();for(int i=0;i<genes.length;i++)order.add(i);
        Collections.shuffle(order,rng);order.sort(Comparator.comparingInt(i->m.choices.get(i).size()));
        for(int i:order){
            var options=new ArrayList<Integer>();for(int k=0;k<m.choices.get(i).size();k++)options.add(k);
            Collections.shuffle(options,rng);boolean placed=false;
            for(int k:options){
                if(stop())return null;boolean fits=true;
                for(int j=0;j<genes.length;j++)if(genes[j]>=0&&m.conflict(i,m.choices.get(i).get(k),j,m.choices.get(j).get(genes[j]))!=null){fits=false;break;}
                if(fits){genes[i]=k;placed=true;break;}
            }
            if(!placed)return null;
        }
        return Evaluator.evaluate(m,genes).valid()?genes:null;
    }
    void evolve(ConstraintSolver cp){evolve(cp,false);}
    void evolve(ConstraintSolver cp,boolean hybrid){
        var population=new ArrayList<Member>();phase="Seeding";
        long seedDeadline=System.nanoTime()+(long)(Math.max(0,left()*.10)*1e9);
        for(int attempt=0;!stop()&&(hybrid?System.nanoTime()<seedDeadline:attempt<settings.population);attempt++){
            int[] seed=greedySeed();if(seed!=null){int cost=inspect(seed);bestGreedySeed=Math.min(bestGreedySeed,cost);if(cost!=Integer.MAX_VALUE&&population.stream().noneMatch(member->Arrays.equals(member.genes(),seed))){if(population.size()<settings.population)population.add(new Member(seed,cost));else insert(population,seed,cost);}}
        }
        if(population.isEmpty()&&!stop()){
            phase="CP initial seed";int[] seed=cp.solve(this,null,true,Math.min(left(),Math.max(.2,left()*.70)));
            if(seed!=null){int cost=inspect(seed);if(cost!=Integer.MAX_VALUE)population.add(new Member(seed,cost));}
        }
        if(population.isEmpty()||score==0)return;
        while(population.size()<settings.population)population.add(population.get(rng.nextInt(population.size())));
        if(!hybrid){phase="GA generations";evolvePhase(population,settings.generations,Long.MAX_VALUE,cp);return;}
        // Keep the timetable-specific crossover inside Hybrid; ordinary GA is unchanged.
        class HybridGenetics {
            int[] groupCrossover(Member a,Member b){
                var groups=new ArrayList<>(m.stages.keySet());if(groups.isEmpty())return crossover(a,b);
                String group=groups.get(rng.nextInt(groups.size()));int[] child=a.genes().clone();boolean changed=false;
                for(int i=0;i<child.length;i++)if(m.events.get(i).groups().contains(group)){child[i]=b.genes()[i];changed|=child[i]!=a.genes()[i];}
                return changed?child:crossover(a,b);
            }
            void evolve(long deadline){
                for(int g=0;g<gaPhaseGenerations&&!stop()&&System.nanoTime()<deadline&&score>0;g++){
                    var next=new ArrayList<Member>();next.add(new Member(best.clone(),score));
                    while(next.size()<settings.population&&!stop()&&System.nanoTime()<deadline){
                        Member parent=tournament(population);int[] child=groupCrossover(parent,tournament(population));mutate(child);int cost=inspect(child);
                        if(cost==Integer.MAX_VALUE){double slice=Math.min(Math.min(.3,left()),(deadline-System.nanoTime())/1e9);if(slice>0){child=cp.solve(SearchEngine.this,child,false,slice);if(child!=null)cost=inspect(child);}}
                        next.add(cost<Integer.MAX_VALUE?new Member(child,cost):parent);
                    }
                    while(next.size()<settings.population)next.add(population.get(rng.nextInt(population.size())));population.clear();population.addAll(next);
                }
            }
        }
        var genetics=new HybridGenetics();var history=new ArrayDeque<Long>();
        while(!stop()&&score>0){
            long gaBefore=gaImprovements,recentGa=0;for(long count:history)recentGa+=count;
            double gaShare=recentGa>0?.30:history.size()==3?.10:.20;
            double roundBudget=Math.min(left(),settings.seconds*.05);long roundEnd=System.nanoTime()+(long)(roundBudget*1e9);
            phase="GA generations";genetics.evolve(Math.min(roundEnd,System.nanoTime()+(long)(roundBudget*gaShare*1e9)));
            long cpEnd=roundEnd;
            if(!stop()){
                population.sort(Comparator.comparingInt(Member::cost));var elites=new ArrayList<Member>();elites.add(new Member(best.clone(),score));
                int eliteCount=Math.max(1,population.size()/2);for(int i=0;i<2;i++)elites.add(population.get(rng.nextInt(eliteCount)));
                for(int index=0;index<elites.size();index++){var member=elites.get(index);double remaining=(cpEnd-System.nanoTime())/1e9;if(stop()||remaining<=0)break;
                    phase="CP neighbourhood";neighbourhood=neighbourhood(member.genes());
                    try{int[] candidate=cp.solve(this,member.genes().clone(),true,Math.min(left(),remaining/(elites.size()-index)));accept(population,candidate);accept(population,best);}
                    finally{neighbourhood=null;}
                }
            }
            rounds++;
            if(rounds%5==0&&!stop()){
                phase="CP global improvement";hint=best.clone();
                int[] candidate=cp.solve(this,null,true,Math.min(left(),settings.seconds*.20));accept(population,candidate);accept(population,best);
            }
            history.addLast(gaImprovements-gaBefore);if(history.size()>3)history.removeFirst();
        }
        phase=cancelled.getAsBoolean()?"Cancelled":"Finished";
    }
    boolean[] neighbourhood(int[] genes){
        boolean[] move=new boolean[genes.length];int kind=rng.nextInt(3);
        if(kind==0){var groups=new ArrayList<>(m.stages.keySet());String group=groups.get(rng.nextInt(groups.size()));for(int i=0;i<move.length;i++)move[i]=m.events.get(i).groups().contains(group);}
        else if(kind==1){String day=m.days.get(rng.nextInt(m.days.size()));for(int i=0;i<move.length;i++)move[i]=m.choices.get(i).get(genes[i]).day().equals(day);}
        else for(int i=0;i<move.length;i++)move[i]=rng.nextDouble()<.20;
        boolean any=false;for(boolean selected:move)any|=selected;if(!any)move[rng.nextInt(move.length)]=true;return move;
    }
    void accept(List<Member> population,int[] candidate){if(candidate==null)return;int cost=inspect(candidate);if(cost!=Integer.MAX_VALUE)insert(population,candidate,cost);}
    void insert(List<Member> population,int[] candidate,int cost){
        if(population.isEmpty()){population.add(new Member(candidate.clone(),cost));return;}
        int worst=0;for(int i=1;i<population.size();i++)if(population.get(i).cost()>population.get(worst).cost())worst=i;
        if(cost<population.get(worst).cost())population.set(worst,new Member(candidate.clone(),cost));
    }
    void evolvePhase(List<Member> population,int generations,long deadline,ConstraintSolver cp){
        for(int g=0;g<generations&&!stop()&&System.nanoTime()<deadline&&score>0;g++){
            var next=new ArrayList<Member>();next.add(new Member(best.clone(),score));
            while(next.size()<settings.population&&!stop()&&System.nanoTime()<deadline){
                Member parent=tournament(population);int[] child=crossover(parent,tournament(population));mutate(child);int cost=inspect(child);
                if(cost==Integer.MAX_VALUE){double slice=Math.min(Math.min(.3,left()),(deadline-System.nanoTime())/1e9);if(slice>0){child=cp.solve(this,child,false,slice);if(child!=null)cost=inspect(child);}}
                next.add(cost<Integer.MAX_VALUE?new Member(child,cost):parent);
            }
            while(next.size()<settings.population)next.add(population.get(rng.nextInt(population.size())));population.clear();population.addAll(next);
        }
    }
}
