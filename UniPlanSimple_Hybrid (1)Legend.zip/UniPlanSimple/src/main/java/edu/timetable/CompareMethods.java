package edu.timetable;
import java.nio.file.*;
import java.util.*;
/** No-UI comparison: same demo, seeds, time budget and independent evaluator. */
public final class CompareMethods {
    record Run(String method,int seed,int workers,int score,String hard,double seconds,long rounds,long ga,long cp,SearchEngine search){}
    public static void main(String[] args)throws Exception{
        double budget=args.length==0?30:Double.parseDouble(args[0]);int workers=Math.min(8,Runtime.getRuntime().availableProcessors());
        var project=SimpleProject.demo();var model=new ProblemData(project.toData());var runs=new ArrayList<Run>();Path file=Path.of("results/compare-methods.txt");Files.createDirectories(file.getParent());
        for(String method:List.of("CP","GA",SearchEngine.HYBRID))for(int trial=0;trial<4;trial++){
            int seed=trial<3?7+trial:7;int count=trial<3?workers:1;
            var search=new SearchEngine(model,new SearchEngine.Settings(seed,budget,16,100,.12,Long.MAX_VALUE),()->false);search.workers=count;search.run(method,new ConstraintSearch());
            String hard=search.best==null?"NA":Integer.toString(Evaluator.evaluate(model,search.best).violations().size());
            if(search.best!=null&&!hard.equals("0"))throw new AssertionError("Hard violations in "+method);
            var run=new Run(method,seed,count,search.best==null?Integer.MAX_VALUE:search.score,hard,search.elapsed(),search.rounds,search.gaImprovements,search.cpImprovements,search);runs.add(run);Files.writeString(file,report(project,runs,budget,workers,false));
            System.out.printf(Locale.ROOT,"MEASURED %s seed=%d workers=%d score=%s hard=%s seconds=%.3f%n",method,seed,count,run.score()==Integer.MAX_VALUE?"UNKNOWN":run.score(),hard,run.seconds());
        }
        String report=report(project,runs,budget,workers,true);Files.writeString(file,report);System.out.print(report);
    }
    static String report(SimpleProject project,List<Run> runs,double budget,int workers,boolean complete){
        var text=new StringBuilder("Demo: seed 2026; 8 groups, 40 subjects, 64 sessions; unchanged objective/constraints.\n");text.append("Budget per run: ").append(budget).append(" seconds; default workers: ").append(workers).append("; median uses seeds 7/8/9 at default workers only.\n");
        text.append("method | seed | workers | score | hard violations | seconds | rounds | GA improvements | CP improvements\n");
        for(var run:runs)text.append(String.format(Locale.ROOT,"%s | %d | %d | %s | %s | %.3f | %d | %d | %d%n",run.method(),run.seed(),run.workers(),run.score()==Integer.MAX_VALUE?"UNKNOWN":run.score(),run.hard(),run.seconds(),run.rounds(),run.ga(),run.cp()));
        if(!complete)return text.toString();var medians=new LinkedHashMap<String,Integer>();
        for(String method:List.of("CP","GA",SearchEngine.HYBRID)){var matching=runs.stream().filter(r->r.method().equals(method)).limit(3).toList();var scores=matching.stream().mapToInt(Run::score).sorted().toArray();medians.put(method,scores[1]);text.append("median ").append(method).append(" = ").append(scores[1]==Integer.MAX_VALUE?"UNKNOWN":scores[1]).append('\n');}
        boolean hybridWins=medians.get(SearchEngine.HYBRID)<medians.get("CP")&&medians.get(SearchEngine.HYBRID)<medians.get("GA")&&runs.stream().filter(r->r.method().equals(SearchEngine.HYBRID)).limit(3).allMatch(r->r.score()<Integer.MAX_VALUE);
        text.append("recommended_default=").append(hybridWins?SearchEngine.HYBRID:"CP").append('\n').append(hybridWins?"Hybrid has the best median in these three default-worker runs.\n":"Hybrid did not win the median comparison; CP remains the default.\n");
        for(String method:medians.keySet()){var best=runs.stream().filter(r->r.method().equals(method)&&r.score()<Integer.MAX_VALUE).min(Comparator.comparingInt(Run::score));if(best.isEmpty())continue;var run=best.get();text.append("Best ").append(method).append(" run: seed=").append(run.seed()).append(" workers=").append(run.workers()).append(" score=").append(run.score()).append("\ngroup | ").append(String.join(" | ",run.search().m.days)).append('\n');project.sessionsPerDay(run.search()).forEach((group,counts)->{text.append(group);for(int count:counts)text.append(" | ").append(count);text.append('\n');});}
        text.append("Single-machine measurements, not a general superiority claim. Parallel workers and wall-clock limits can vary results. FEASIBLE is not proof of optimality.\n");return text.toString();
    }
}
