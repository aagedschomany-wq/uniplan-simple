# Hard constraints, soft constraints and mutation

Research checked 14 November 2026. There is no single universal list: local policy decides which preferences matter. This project uses a conventional resource-conflict model and keeps the user's capacity and breaks mandatory.

| Rule in this project | Level | Enforcement |
|---|---|---|
| One class per room at a time | Hard | CP optional room intervals / NoOverlap; independent evaluator |
| An instructor cannot teach overlapping classes | Hard | Instructor NoOverlap; evaluator |
| A student group cannot attend overlapping classes | Hard | Group NoOverlap; evaluator |
| Classroom for Theory, Lab for Lab, enough seats | Hard | Eligible placement domain; health diagnostics |
| Exact number and duration of weekly sessions | Hard | One event per session, exactly one placement per event |
| Only selected days and teaching periods, never breaks | Hard | Placement domain and fixed blocked periods in Simple mode |
| Minimize idle gaps for students | Soft | Active teaching minutes between first/last attendance, excluding blocked time and occupied sessions |
| Balance teaching across selected days | Soft | For each group/day: abs(dayCount × dailyTeachingMinutes − weeklyTeachingMinutes) |

Fixed objective = student gap minutes + balance penalty, both weight 1. A feasible timetable must satisfy every hard rule. A lower soft score can never compensate for a hard violation. Optional blank instructors cannot protect against conflicts for a real unnamed person: enter their same name everywhere to enforce this.

## What the public projects teach us

- Timefold school quickstart lists room/teacher/group conflicts as hard, teacher room stability/time efficiency and student subject variety as soft: https://github.com/TimefoldAI/timefold-quickstarts/blob/stable/use-cases/school-timetabling/README.md
- Timefold university course model illustrates that conventions differ: its ITC 2007 model treats room capacity as soft. Here capacity stays **hard**, as requested: https://docs.timefold.ai/timefold-solver/0.8.x/use-cases-and-examples/course-timetabling/course-timetabling
- UniTime explains resource constraints and required/prohibited versus preferred distributions: https://help-unitime.unitime.org/uct_description.php ; https://help.unitime.org/manuals/courses-entry

We apply the shared modeling practices rather than claiming to implement every rule in those larger products. Travel time, subject variety, instructor room stability, dates and personal preferences are not additional hidden rules in this version. No public code or framework was added.

## Genetic algorithm and mutation

CP is the reliable default. Select GA under Advanced to run the existing genetic search with randomized constructive seeding, CP fallback and CP repair. Constructive seeding shuffles event order, places the most constrained domains first, and tries random eligible placements without resource conflicts. The full evaluator checks each completed seed. If no feasible seed is constructed, CP gets a longer fallback attempt. A candidate is an array of placement indices, one per session. Selection picks the best of three randomly sampled parents. Uniform crossover chooses each gene from either parent. With probability 0.12 per gene, mutation selects a **different** placement from that session's eligible domain. One-choice genes cannot mutate. The seed is fixed at 7; the time limit is editable.

A domain-valid mutation can still conflict with another event. The evaluator rejects such offspring, then CP attempts repair within its allocated budget. Elitism preserves the best feasible timetable. Mutation therefore explores alternatives without publishing invalid timetables. GA is a heuristic: neither mutations nor time limits guarantee a global optimum. If seeding proves a zero objective, the nonnegative score cannot improve and GA stops immediately. The UI displays the actual number of changed genes, not attempted probability draws.
