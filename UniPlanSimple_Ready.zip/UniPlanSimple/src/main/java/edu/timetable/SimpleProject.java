package edu.timetable;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import com.google.gson.*;

/** Small UI-facing document. Conversion is the boundary to the unchanged solver model. */
final class SimpleProject {
    static final int MAX_ENROLLMENT=1_000_000;
    static final List<String> WEEK=List.of("Sunday","Monday","Tuesday","Wednesday","Thursday");
    static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    int schemaVersion=1;
    String format="UniPlanSimple",university="",college="",department="";
    List<Group> groups=new ArrayList<>();
    List<Subject> subjects=new ArrayList<>();
    List<Day> days=new ArrayList<>();
    List<Room> rooms=new ArrayList<>();
    record Group(int stage,String name){String id(){return stage+" "+name;} public String toString(){return "Stage "+stage+" · Group "+name;}}
    record Subject(String id,int stage,String group,String name,String type,int students,int sessions,int minutes,String instructor){}
    record Break(int start,int end){}
    record Day(String name,boolean enabled,int start,int end,int classMinutes,List<Break> breaks){Day{breaks=List.copyOf(breaks);}}
    record Room(String name,String type,int capacity){}
    record Issue(boolean error,int step,String message){}
    static SimpleProject blank(){
        var p=new SimpleProject();for(int s=1;s<=4;s++)p.groups.add(new Group(s,"A"));
        for(String day:WEEK)p.days.add(new Day(day,true,540,900,90,List.of(new Break(630,660),new Break(750,780))));return p;
    }
    int defaultMinutes(){return days.stream().filter(Day::enabled).mapToInt(Day::classMinutes).findFirst().orElse(90);}
    String json(){return JSON.toJson(this);}
    static SimpleProject parse(String content){
        var p=JSON.fromJson(content,SimpleProject.class);
        if(p==null||!"UniPlanSimple".equals(p.format)||p.schemaVersion!=1||p.groups==null||p.subjects==null||p.days==null||p.rooms==null||p.university==null||p.college==null||p.department==null)
            throw new IllegalArgumentException("Open a UniPlan Simple JSON file (schema 1). UniPlan5 files use a different format.");
        if(p.days.size()!=5||!new HashSet<>(p.days.stream().map(Day::name).toList()).equals(new HashSet<>(WEEK)))throw new IllegalArgumentException("The file must contain Sunday through Thursday exactly once.");
        if(p.groups.stream().anyMatch(g->g==null||g.name()==null)||p.subjects.stream().anyMatch(s->s==null||s.id()==null||s.name()==null||s.type()==null||s.group()==null||s.instructor()==null)||p.rooms.stream().anyMatch(r->r==null||r.name()==null||r.type()==null))throw new IllegalArgumentException("The file contains a missing field.");
        return p;
    }
    static SimpleProject load(Path file)throws IOException{return parse(Files.readString(file));}
    void save(Path file)throws IOException{
        Path target=file.toAbsolutePath();Files.createDirectories(target.getParent());Path tmp=Files.createTempFile(target.getParent(),"uniplan-", ".tmp");
        try{Files.writeString(tmp,json());try{Files.move(tmp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException ex){Files.move(tmp,target,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(tmp);}
    }
    static boolean validName(String value){return value!=null&&!value.isBlank()&&value.length()<=100&&!value.contains("\n");}
    static boolean validGroup(String value){return validName(value)&&!value.contains(",");}
    /** Breaks are fixed blocked periods; leftover time shorter than a full daily slot is unavailable. */
    static List<String[]> periods(Day day){
        var result=new ArrayList<String[]>();int cursor=day.start();
        var breaks=day.breaks().stream().sorted(Comparator.comparingInt(Break::start)).toList();
        for(var pause:breaks){teaching(result,day,cursor,pause.start());result.add(new String[]{day.name(),"Break",Data.clock(pause.start()),Data.clock(pause.end()),"Required break"});cursor=pause.end();}
        teaching(result,day,cursor,day.end());return result;
    }
    static void teaching(List<String[]> out,Day d,int start,int end){
        while(start+d.classMinutes()<=end){int next=start+d.classMinutes();out.add(new String[]{d.name(),"Class period",Data.clock(start),Data.clock(next),"Teaching"});start=next;}
        if(start<end)out.add(new String[]{d.name(),"Short remainder",Data.clock(start),Data.clock(end),"Unavailable"});
    }
    static String dayError(Day d){
        if(d.start()<0||d.end()>1439||d.start()>=d.end())return d.name()+": end must be after start (00:00–23:59).";
        if(d.classMinutes()<15||d.classMinutes()>240)return d.name()+": class length must be 15–240 minutes.";
        int previous=d.start();for(var b:d.breaks().stream().sorted(Comparator.comparingInt(Break::start)).toList()){
            if(b.start()<previous||b.end()<=b.start()||b.end()>d.end())return d.name()+": breaks must be inside the day, end after start and never overlap.";previous=b.end();
        }
        if(periods(d).stream().noneMatch(r->r[4].equals("Teaching")))return d.name()+": no complete class period fits. Shorten the class length or extend the day.";
        return "";
    }
    List<Issue> health(){
        var issues=new ArrayList<Issue>();
        if(!validName(university))issues.add(new Issue(true,0,"Enter University (1–100 characters)."));
        if(!validName(college))issues.add(new Issue(true,0,"Enter College (1–100 characters)."));
        if(!validName(department))issues.add(new Issue(true,0,"Enter Department (1–100 characters)."));
        var ids=new HashSet<String>();for(var g:groups)if(g.stage()<1||g.stage()>4||!validGroup(g.name())||!ids.add(g.id().toLowerCase(Locale.ROOT)))issues.add(new Issue(true,1,"Groups need a stage 1–4 and a unique nonempty name within that stage, without commas."));
        for(int s=1;s<=4;s++){final int stage=s;if(groups.stream().noneMatch(g->g.stage()==stage))issues.add(new Issue(true,1,"Stage "+s+" needs at least one group."));}
        if(subjects.isEmpty())issues.add(new Issue(true,2,"Add at least one subject."));
        if(days.stream().noneMatch(Day::enabled))issues.add(new Issue(true,3,"Select at least one teaching day."));
        for(var d:days)if(d.enabled()&&!dayError(d).isEmpty())issues.add(new Issue(true,3,dayError(d)));
        if(rooms.isEmpty())issues.add(new Issue(true,4,"Add at least one classroom or lab."));
        var roomNames=new HashSet<String>();for(var r:rooms)if(!validName(r.name())||!roomNames.add(r.name().toLowerCase(Locale.ROOT))||!Set.of("Classroom","Lab").contains(r.type())||r.capacity()<1||r.capacity()>MAX_ENROLLMENT)issues.add(new Issue(true,4,"Rooms need unique names, a Classroom/Lab type and capacity 1–1,000,000."));
        var subjectIds=new HashSet<String>();
        for(var s:subjects){
            if(!subjectIds.add(s.id())||!validName(s.name())||!Set.of("Theory","Lab").contains(s.type())||s.students()<1||s.students()>MAX_ENROLLMENT||s.sessions()<1||s.sessions()>20||s.minutes()<15||s.minutes()>240||groups.stream().noneMatch(g->g.stage()==s.stage()&&g.name().equals(s.group()))) {issues.add(new Issue(true,2,"Check subject "+s.name()+": group, type, enrollment, sessions and length."));continue;}
            int capacity=rooms.stream().filter(r->r.type().equals(s.type().equals("Theory")?"Classroom":"Lab")).mapToInt(Room::capacity).max().orElse(0);
            if(capacity<s.students())issues.add(new Issue(true,4,"Subject "+s.name()+" ("+s.stage()+s.group()+") has "+s.students()+" students but the biggest "+(s.type().equals("Theory")?"classroom":"lab")+" holds "+capacity+". Add a room or split the group."));
            if(days.stream().filter(Day::enabled).filter(d->dayError(d).isEmpty()).noneMatch(d->d.classMinutes()>=s.minutes()))issues.add(new Issue(true,3,"Subject "+s.name()+" needs "+s.minutes()+" minutes. Increase a day's class length to fit it."));
            if(s.instructor().isBlank())issues.add(new Issue(false,2,s.name()+" ("+s.stage()+s.group()+"): instructor not assigned; no real instructor conflict can be checked for this subject."));
        }
        for(var g:groups)if(subjects.stream().noneMatch(s->s.stage()==g.stage()&&s.group().equals(g.name())))issues.add(new Issue(false,2,g+" has no subjects yet."));
        return issues;
    }
    Data toData(){
        var errors=health().stream().filter(Issue::error).toList();if(!errors.isEmpty())throw new IllegalArgumentException(errors.getFirst().message());
        Data d=new Data();d.rows.get("Campus").add(new String[]{university,department,"Weekly timetable","5","90","0","after","yes","groups"});
        d.rows.get("Institution").add(new String[]{college,"1","1","0"});
        d.rows.get("Weights").add(new String[]{"1","0","1","0","0","0","0","0","0"});
        d.rows.get("Preferences").add(new String[]{"00:00","23:59","12:00","13:00","1"});
        for(int s=1;s<=4;s++)d.rows.get("Stages").add(new String[]{"Stage "+s});
        for(var g:groups)d.rows.get("Groups").add(new String[]{g.id(),"Stage "+g.stage()});
        for(var day:days)if(day.enabled()){d.rows.get("Days").add(new String[]{day.name(),Data.clock(day.start()),Data.clock(day.end())});d.rows.get("Periods").addAll(periods(day));}
        var teachers=new HashSet<String>();for(var s:subjects){
            String teacher=s.instructor().isBlank()?"__unassigned_"+s.id():s.instructor().trim();
            if(teachers.add(teacher))d.rows.get("Teachers").add(new String[]{teacher,"","*"});
            d.rows.get("Subjects").add(new String[]{s.id(),s.name(),teacher,new Group(s.stage(),s.group()).id(),"",""+s.students(),s.type().equals("Theory")?"Lecture":"Lab",""+s.sessions(),""+s.minutes(),"0","after","yes"});
        }
        for(var r:rooms)d.rows.get("Rooms").add(new String[]{r.name(),r.type().equals("Classroom")?"Lecture":"Lab",""+r.capacity(),"*"});return d;
    }
    static SimpleProject demo(){
        var p=blank();p.university="Salahaddin University";p.college="College of Engineering";p.department="Software & Informatics Engineering";p.groups.clear();
        String[][] names={{"Programming I","Mathematics I","English","Programming Lab","Computer Fundamentals Lab"},{"Data Structures","Database Systems","Mathematics II","Database Lab","Networks Lab"},{"Operating Systems","Web Development","Software Testing","Web Lab","Systems Lab"},{"Artificial Intelligence","Machine Learning","Optimization Methods","AI Lab","Embedded Systems Lab"}};
        for(int stage=1;stage<=4;stage++)for(String group:List.of("A","B")){
            p.groups.add(new Group(stage,group));for(int n=0;n<5;n++)p.subjects.add(new Subject("S"+stage+group+n,stage,group,names[stage-1][n],n<3?"Theory":"Lab",n<3?35:25,n<3?2:1,90,"Demo Instructor "+(1+(stage*3+n)%14)));
        }
        for(int r=1;r<=10;r++)p.rooms.add(new Room("Classroom "+r,"Classroom",r<=5?40:60));
        for(int r=1;r<=4;r++)p.rooms.add(new Room("Lab "+r,"Lab",30));return p;
    }
}
