# UniPlan Simple — data dictionary

All durations are minutes. Time is local 24-hour time; there are no semester dates or time zones. Fields have visible labels, tooltips and inline errors. Numeric and time controls are noneditable spinners: use arrows or Up/Down keys. Text errors are validated beside the field. Cross-field time errors appear inside the day's card.

| Screen | Label | Data type | Example | Rule |
|---|---|---|---|---|
| 1 University | University (text) | String | Salahaddin University | Required, 1–100 characters, one line. |
| 1 University | College (text) | String | College of Engineering | Required, 1–100 characters, one line. |
| 1 University | Department (text) | String | Software & Informatics Engineering | Required, 1–100 characters, one line. |
| 2 Stages & groups | Stage (whole number) | Integer spinner | 4 | 1–4. Four stages are fixed; each needs at least one group. |
| 2 Stages & groups | Group (text) | String | A | Required, 1–100 characters, no commas, unique within stage ignoring case. Renaming a group updates its subjects. |
| 3 Subjects | Selected stage (int) | Choice of integers | 4 | One of 1, 2, 3, 4. Filters the form/list. |
| 3 Subjects | Selected group (text) | Choice of group names | A | Existing group in selected stage. |
| 3 Subjects | Subject name (text) | String | Machine Learning | Required, 1–100 characters. Same name and type cannot be added twice to the same group through the form; edit session count instead. |
| 3 Subjects | Type | Enumeration | Theory | Theory or Lab. Maps to engine room type Lecture or Lab. |
| 3 Subjects | Number of students (whole number) | Integer spinner | 35 | 1–1000. Each subject has its own count; must fit an eligible room. |
| 3 Subjects | Sessions per week (whole number) | Integer spinner | 2 | 1–20. Exactly this many events are generated. |
| 3 Subjects | Session length (minutes) | Integer spinner | 90 | 15–240, exact duration of every weekly session. New subject default is the class length of the first selected teaching day. Existing values do not change silently. |
| 3 Subjects | Instructor (optional text) | String | Dr. Narin | 0–100 characters. Reuse exactly the same spelling for a shared instructor. Blank means genuinely unassigned; no actual instructor availability/conflict can be inferred. |
| 4 Days & times | Sunday … Thursday | Boolean checkboxes | Sunday selected | All five selected by default. At least one selected; disabled days preserve settings but are not scheduled. |
| 4 Days & times | Start time (24-hour) | Hour/minute spinners | 09:00 | Hour 0–23, minute 0–59; earlier than end. |
| 4 Days & times | End time (24-hour) | Hour/minute spinners | 15:00 | Same ranges; later than start. No overnight teaching. |
| 4 Days & times | Class length (minutes) | Integer spinner | 90 | 15–240. Divides each teaching span into complete class periods. Any short remainder is unavailable. |
| 4 Days & times | Break start (24-hour) | Hour/minute spinners | 10:30 | Inside the selected day, earlier than break end. |
| 4 Days & times | Break end (24-hour) | Hour/minute spinners | 11:00 | Inside the day, later than start. Breaks cannot overlap; at least one full class period must remain. |
| 4 Days & times | Copy to other days | Boolean selections | Monday and Tuesday | Replaces selected days' start/end/length/breaks; does not enable/disable days. |
| 5 Rooms | Room name (text) | String | Classroom 1 | Required, 1–100 characters, unique ignoring case. |
| 5 Rooms | Type | Enumeration | Classroom | Classroom or Lab. |
| 5 Rooms | Capacity (students) | Integer spinner | 40 | 1–1000. Hard capacity constraint. |
| 6 Review | Go fix it | Navigation action | Go fix it → Rooms | Links each diagnostic to the relevant editable page. Red blocks generation; amber warns. |
| 7 Generate | Time limit (seconds) | Integer spinner | 20 | 1–300. Maximum solver search budget; native shutdown may add a small overhead. |
| 7 Generate / Advanced | Method | Enumeration | CP | CP default; Random and Exhaustive baseline options. Seed fixed at 7, one CP worker. |
| Timetable | Stage / Group / Room / Instructor | Choice filters | Stage 4 / 4 A | All or an existing value. Multiple filters intersect; CSV exports visible events, HTML exports the whole week. |

## Deliberately hidden/fixed values

The adapter sets zero per-subject rest (breaks come from daily inputs), 5-minute candidate-start steps inside each full class period, no calendar dates, no custom rules/locks/workloads, and fixed objective weights: student gaps = 1, daily balance = 1, all other terms = 0. The balance penalty is the existing engine's sum of |D × daily teaching minutes − weekly teaching minutes| per group/day. It encourages spreading lessons; it is not a hard attendance-day requirement.

A subject may be shorter than a day class period, but cannot cross its boundary. A 120-minute subject cannot use a day configured with 90-minute periods: Review explains which setting to change. Starts are selected every five minutes from the period's start, so a 09:10 period starts on its own grid, not on an assumed 09:00 grid.

Subjects have generated stable IDs in JSON, separate from their names. Group engine IDs combine stage and group name, e.g. `4 A`. Different groups are treated as disjoint student groups in Simple; cross-group individual student enrollment is not an input in this version. Use a separate subject row for each group. Stage A and B are not automatically combined into shared lectures.
