package edu.timetable;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
/** Export styling derives its colors from the same palette as JavaFX. */
final class SimpleExport {
    static String htmlCss()throws IOException{
        String css=new String(SimpleExport.class.getResourceAsStream("/studio.css").readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
        var vars=new StringBuilder(":root{");var match=Pattern.compile("-([a-z]+):\\s*(#[0-9a-fA-F]{6})").matcher(css);while(match.find())vars.append("--").append(match.group(1)).append(':').append(match.group(2)).append(';');vars.append('}');
        return vars+"*{box-sizing:border-box}body{background:var(--page);color:var(--ink);font:14px sans-serif;margin:24px}h1{font-size:22px;color:var(--forest)}table{border-spacing:2px;width:100%;font-size:11px}td{padding:6px;text-align:center;border-radius:3px;background:var(--page)}.heading,.day{background:var(--forest);color:var(--page);font-weight:bold}.hour,.lecture{background:var(--mint)}.lab0{background:var(--teal)}.lab1{background:var(--lime)}.lab2{background:var(--warning)}.closure{background:var(--grey)}@page{size:A3 landscape;margin:8mm}@media print{body{margin:0}td{padding:3px}*{print-color-adjust:exact}}";
    }
    static void csv(Path file,List<String[]> rows)throws IOException{
        try(var out=Files.newBufferedWriter(file)){out.write("Day,Start,Finish,Subject,Instructor,Groups,Room\n");for(var row:rows){var escaped=new ArrayList<String>();for(String value:row)escaped.add("\""+value.replace("\"","\"\"")+"\"");out.write(String.join(",",escaped)+"\n");}}
    }
}
