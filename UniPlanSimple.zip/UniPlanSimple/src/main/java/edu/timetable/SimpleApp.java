package edu.timetable;

import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.Insets;
import javafx.animation.*;
import javafx.concurrent.Task;
import javafx.util.Duration;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import java.nio.file.*;
import java.util.*;
import java.util.function.*;
import java.io.*;
import static edu.timetable.SimpleFields.*;

/** Seven small screens. All optimization remains in the existing solver classes. */
public final class SimpleApp extends Application {
    SimpleProject project=SimpleProject.blank();
    final String[] steps={"University","Stages & groups","Subjects","Days & times","Rooms","Review","Generate"};
    final BorderPane root=new BorderPane();final VBox page=new VBox(20),sidebar=new VBox(8),content=new VBox(14);
    final Label status=new Label("New department • not saved"),pageError=new Label(),runStatus=new Label();
    final Button next=button("Next →",()->go(this.step+1)),back=button("← Back",()->go(this.step-1));
    final ProgressBar progress=new ProgressBar(0);final ProgressIndicator wizardProgress=new ProgressIndicator(1.0/7);
    final SimpleFields.Field<Integer> limit=number("Time limit (seconds)",20,1,300);
    final SimpleFields.Field<String> method=choice("Method","CP",List.of("CP","Random","Exhaustive"));
    final Path recovery=Path.of(System.getProperty("user.home"),".uniplan-simple","autosave.json");
    final PauseTransition autosave=new PauseTransition(Duration.millis(500));
    Stage stage;int step;boolean busy,dirty;Path currentFile;SearchEngine result;volatile SearchEngine live;Task<SearchEngine> task;
    int selectedStage=1;String selectedGroup="A";
    final List<Node> fileButtons=new ArrayList<>();
    final List<SimpleFields.Field<?>> visibleFields=new ArrayList<>();
    final ComboBox<String> stageFilter=new ComboBox<>(),groupFilter=new ComboBox<>(),roomFilter=new ComboBox<>(),teacherFilter=new ComboBox<>();
    final VBox timetable=new VBox(12);final List<String[]> visibleRows=new ArrayList<>();
    final Label gridDetail=new Label("Select a class to see its details.");
    @Override public void start(Stage primary){
        stage=primary;stage.setTitle("UniPlan Simple");
        var brand=new Label("UniPlan Simple");brand.getStyleClass().add("brand");
        var subtitle=new Label("A clear weekly timetable for your department");subtitle.getStyleClass().add("header-note");
        var newFile=button("New",()->{if(discardChanges())replace(SimpleProject.blank(),null);});var open=button("Open JSON",this::open);var save=button("Save JSON",this::save);
        var demo=button("Load demo data",()->{if(discardChanges())replace(SimpleProject.demo(),null);});var recover=button("Recover autosave",()->{try{replace(SimpleProject.load(recovery),null);}catch(Exception ex){showError(ex);}});
        fileButtons.addAll(List.of(newFile,open,save,demo,recover));
        var actions=new FlowPane(8,8,newFile,open,save,demo,recover);var heading=new VBox(5,brand,subtitle);
        var header=new HBox(24,heading,actions);header.getStyleClass().add("header");HBox.setHgrow(heading,Priority.ALWAYS);header.setAlignment(javafx.geometry.Pos.CENTER_LEFT);root.setTop(header);
        sidebar.getStyleClass().add("sidebar");sidebar.setPrefWidth(205);wizardProgress.setPrefSize(36,36);
        for(int i=0;i<steps.length;i++){final int index=i;var b=button((i+1)+"   "+steps[i],()->go(index));b.setMaxWidth(Double.MAX_VALUE);b.setId("step-"+i);sidebar.getChildren().add(b);}
        sidebar.getChildren().addAll(new Separator(),wizardProgress,note("Four stages. One weekly schedule."));root.setLeft(sidebar);
        var scroller=new ScrollPane(page);scroller.setFitToWidth(true);scroller.setPannable(true);VBox.setVgrow(scroller,Priority.ALWAYS);page.setPadding(new Insets(26));
        pageError.getStyleClass().add("error");pageError.setWrapText(true);
        var spacer=new Region();HBox.setHgrow(spacer,Priority.ALWAYS);var nav=new HBox(12,back,spacer,next);nav.setPadding(new Insets(8,24,18,24));
        content.getChildren().addAll(scroller,pageError,nav);root.setCenter(content);
        status.setPadding(new Insets(10,24,12,24));root.setBottom(status);
        autosave.setOnFinished(e->{try{project.save(recovery);status.setText("Unsaved edits • recovery copy saved");}catch(Exception ex){status.setText("Autosave failed: "+ex.getMessage());}});
        Scene scene=new Scene(root,1420,960);scene.getStylesheets().add(getClass().getResource("/studio.css").toExternalForm());stage.setScene(scene);stage.setMinWidth(1050);stage.setMinHeight(740);
        stage.setOnCloseRequest(e->{autosave.stop();try{if(dirty)project.save(recovery);}catch(Exception ex){System.err.println("Autosave on exit: "+ex.getMessage());}if(task!=null)task.cancel();});
        render();stage.show();if(Boolean.getBoolean("simple.smoke"))Platform.runLater(()->SimpleSmoke.run(this));
    }
    void changed(){dirty=true;result=null;autosave.playFromStart();status.setText("Unsaved edits • previous timetable cleared");}
    void replace(SimpleProject p,Path file){if(busy)return;autosave.stop();project=p;currentFile=file;step=0;selectedStage=1;selectedGroup=project.groups.stream().filter(g->g.stage()==1).map(SimpleProject.Group::name).findFirst().orElse("A");changed();render();}
    boolean discardChanges(){return !dirty||new Alert(Alert.AlertType.CONFIRMATION,"Replace the current unsaved inputs? Save JSON first if you want to keep them.",ButtonType.CANCEL,ButtonType.OK).showAndWait().orElse(ButtonType.CANCEL)==ButtonType.OK;}
    void open(){if(!discardChanges())return;var chooser=new FileChooser();chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("UniPlan Simple JSON","*.json"));var f=chooser.showOpenDialog(stage);if(f!=null)try{var p=SimpleProject.load(f.toPath());replace(p,f.toPath());status.setText("Opened "+f.getName());}catch(Exception ex){showError(ex);}}
    void save(){var chooser=new FileChooser();chooser.setInitialFileName(currentFile==null?"MyDepartment.json":currentFile.getFileName().toString());chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("UniPlan Simple JSON","*.json"));var f=chooser.showSaveDialog(stage);if(f!=null)try{autosave.stop();project.save(f.toPath());currentFile=f.toPath();dirty=false;status.setText("Saved "+f.getName());}catch(Exception ex){showError(ex);}}
    void showError(Throwable ex){new Alert(Alert.AlertType.ERROR,Objects.toString(ex.getMessage(),ex.toString()),ButtonType.OK).showAndWait();}
    boolean validatePage(){
        boolean ok=true;for(var field:visibleFields)ok=field.valid()&&ok;
        var problems=project.health().stream().filter(i->i.error()&&i.step()==step).toList();
        pageError.setText(problems.isEmpty()?"":problems.getFirst().message());return ok&&problems.isEmpty();
    }
    void go(int target){if(busy||target<0||target>=steps.length)return;if(target>step&&!validatePage())return;step=target;render();}
    void render(){
        visibleFields.clear();page.getChildren().clear();page.setSpacing(step==6?12:20);pageError.setText("");
        for(int i=0;i<7;i++){sidebar.getChildren().get(i).getStyleClass().remove("step-active");if(i==step)sidebar.getChildren().get(i).getStyleClass().add("step-active");}
        wizardProgress.setProgress((step+1)/7.0);back.setDisable(step==0||busy);next.setVisible(step<6);next.setManaged(step<6);
        var title=new Label(steps[step]);title.getStyleClass().add("page-title");page.getChildren().add(title);
        switch(step){case 0->institution();case 1->groups();case 2->subjects();case 3->days();case 4->rooms();case 5->review();case 6->generation();default->throw new IllegalStateException();}
    }
    void institution(){
        var u=text("University (text)",project.university,true);var c=text("College (text)",project.college,true);var d=text("Department (text)",project.department,true);
        u.watch(()->{project.university=u.value();changed();});c.watch(()->{project.college=c.value();changed();});d.watch(()->{project.department=d.value();changed();});
        visibleFields.addAll(List.of(u,c,d));page.getChildren().addAll(u,c,d);
    }
    <T> TableView<T> table(List<T> rows,String[] headings,List<Function<T,String>> values){
        var t=new TableView<T>(FXCollections.observableArrayList(rows));t.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);t.setPrefHeight(Math.min(380,Math.max(160,rows.size()*42+42)));t.setPlaceholder(note("No records yet. Use Add to begin."));
        for(int i=0;i<headings.length;i++){final int k=i;var col=new TableColumn<T,String>(headings[i]);col.setCellValueFactory(v->new ReadOnlyStringWrapper(values.get(k).apply(v.getValue())));t.getColumns().add(col);}return t;
    }
    void groups(){
        page.getChildren().add(note("Stages 1–4 are fixed. Each stage needs at least one group. Subjects belong to one group."));
        var t=table(project.groups,new String[]{"Stage (int)","Group (text)"},List.of(g->""+g.stage(),SimpleProject.Group::name));
        page.getChildren().addAll(new HBox(10,button("Add group",()->groupDialog(null)),button("Edit selected",()->{var g=t.getSelectionModel().getSelectedItem();if(g!=null)groupDialog(g);}),button("Remove selected",()->{
            var g=t.getSelectionModel().getSelectedItem();if(g==null)return;
            if(project.subjects.stream().anyMatch(s->s.stage()==g.stage()&&s.group().equals(g.name()))){pageError.setText("Remove this group's subjects before removing the group.");return;}
            project.groups.remove(g);changed();render();})),t);
    }
    void groupDialog(SimpleProject.Group old){
        var stageField=number("Stage (whole number)",old==null?selectedStage:old.stage(),1,4);var name=text("Group (text)",old==null?"B":old.name(),true);
        form("Group",List.of(stageField,name),()->{
            var g=new SimpleProject.Group(stageField.value(),name.value());
            if(!SimpleProject.validGroup(g.name()))return "Group name cannot contain a comma.";
            if(project.groups.stream().anyMatch(x->x!=old&&x.stage()==g.stage()&&x.name().equalsIgnoreCase(g.name())))return "This group already exists in this stage.";return "";
        },()->{
            var g=new SimpleProject.Group(stageField.value(),name.value());
            if(old==null)project.groups.add(g);else{
                project.groups.set(project.groups.indexOf(old),g);
                project.subjects.replaceAll(s->s.stage()==old.stage()&&s.group().equals(old.name())?new SimpleProject.Subject(s.id(),g.stage(),g.name(),s.name(),s.type(),s.students(),s.sessions(),s.minutes(),s.instructor()):s);
            }selectedStage=g.stage();selectedGroup=g.name();project.groups.sort(Comparator.comparingInt(SimpleProject.Group::stage).thenComparing(SimpleProject.Group::name));changed();render();
        });
    }
    void subjects(){
        var stageChoice=choice("Selected stage (int)",selectedStage,List.of(1,2,3,4));
        var names=project.groups.stream().filter(g->g.stage()==selectedStage).map(SimpleProject.Group::name).toList();if(!names.contains(selectedGroup))selectedGroup=names.isEmpty()?null:names.getFirst();
        var groupChoice=choice("Selected group (text)",selectedGroup,names);
        stageChoice.watch(()->{selectedStage=stageChoice.value();render();});groupChoice.watch(()->{selectedGroup=groupChoice.value();render();});
        page.getChildren().addAll(new HBox(20,stageChoice,groupChoice),note("New session length defaults to the first selected day's class length (currently "+project.defaultMinutes()+" minutes). Existing subject lengths stay unchanged when daily times change."));
        var rows=project.subjects.stream().filter(s->s.stage()==selectedStage&&s.group().equals(selectedGroup)).toList();
        var t=table(rows,new String[]{"Subject","Type","Students","Sessions/week","Length (min)","Instructor"},List.of(SimpleProject.Subject::name,SimpleProject.Subject::type,s->""+s.students(),s->""+s.sessions(),s->""+s.minutes(),s->s.instructor().isBlank()?"Not assigned":s.instructor()));
        page.getChildren().addAll(new HBox(10,button("Add subject",()->{if(selectedGroup==null){pageError.setText("Add a group to this stage first.");return;}subjectDialog(null);}),button("Edit selected",()->{var s=t.getSelectionModel().getSelectedItem();if(s!=null)subjectDialog(s);}),button("Remove selected",()->{var s=t.getSelectionModel().getSelectedItem();if(s!=null){project.subjects.remove(s);changed();render();}})),t,note(rows.size()+" subjects for Stage "+selectedStage+", Group "+Objects.toString(selectedGroup,"—")+" • "+project.subjects.size()+" in the whole department"));
    }
    void subjectDialog(SimpleProject.Subject old){
        var name=text("Subject name (text)",old==null?"":old.name(),true);var type=choice("Type",old==null?"Theory":old.type(),List.of("Theory","Lab"));
        var count=number("Number of students (whole number)",old==null?30:old.students(),1,1000);var sessions=number("Sessions per week (whole number)",old==null?1:old.sessions(),1,20);var minutes=number("Session length (minutes)",old==null?project.defaultMinutes():old.minutes(),15,240);var teacher=text("Instructor (optional text)",old==null?"":old.instructor(),false);
        form("Subject • Stage "+selectedStage+" / Group "+selectedGroup,List.of(name,type,count,sessions,minutes,teacher),()->{
            if(project.subjects.stream().anyMatch(s->s!=old&&s.stage()==selectedStage&&s.group().equals(selectedGroup)&&s.name().equalsIgnoreCase(name.value())&&s.type().equals(type.value())))return "This subject and type already exist for this group. Edit its sessions instead.";return "";
        },()->{var s=new SimpleProject.Subject(old==null?UUID.randomUUID().toString():old.id(),selectedStage,selectedGroup,name.value(),type.value(),count.value(),sessions.value(),minutes.value(),teacher.value());if(old==null)project.subjects.add(s);else project.subjects.set(project.subjects.indexOf(old),s);changed();render();});
    }
    void form(String title,List<SimpleFields.Field<?>> fields,Supplier<String> validate,Runnable commit){
        var dialog=new Dialog<ButtonType>();dialog.initOwner(stage);dialog.setTitle(title);dialog.setResizable(true);dialog.getDialogPane().getStylesheets().add(getClass().getResource("/studio.css").toExternalForm());
        var body=new VBox(10);body.getChildren().addAll(fields);body.setPadding(new Insets(16));var message=new Label();message.getStyleClass().add("error");message.setWrapText(true);body.getChildren().add(message);
        var scroll=new ScrollPane(body);scroll.setFitToWidth(true);scroll.setPrefViewportWidth(520);scroll.setPrefViewportHeight(Math.min(650,fields.size()*100+60));dialog.getDialogPane().setContent(scroll);dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL,ButtonType.OK);
        Runnable check=()->{boolean valid=true;for(var f:fields)valid=f.valid()&&valid;String error=validate.get();message.setText(error);dialog.getDialogPane().lookupButton(ButtonType.OK).setDisable(!valid||!error.isEmpty());};fields.forEach(f->f.watch(check));check.run();
        if(dialog.showAndWait().orElse(ButtonType.CANCEL)==ButtonType.OK)commit.run();
    }
    void days(){
        page.getChildren().add(note("Each selected day has its own full class periods. A shorter final remainder is unavailable. Subjects must fit within one class period; breaks cannot contain a class."));
        var checks=new HBox(16);for(int i=0;i<project.days.size();i++){final int index=i;var d=project.days.get(i);var box=new CheckBox(d.name());box.setSelected(d.enabled());box.setTooltip(new Tooltip("Boolean: selected = teaching day. Default: Sunday through Thursday."));box.setOnAction(e->{project.days.set(index,new SimpleProject.Day(d.name(),box.isSelected(),d.start(),d.end(),d.classMinutes(),d.breaks()));changed();render();});checks.getChildren().add(box);}page.getChildren().add(checks);
        for(int i=0;i<project.days.size();i++)if(project.days.get(i).enabled())dayCard(i);
    }
    void dayCard(int index){
        var day=project.days.get(index);var card=new VBox(12);card.getStyleClass().add("card");var title=new Label(day.name());title.getStyleClass().add("section-title");
        var start=new SimpleFields.Time("Start time (24-hour)",day.start());var end=new SimpleFields.Time("End time (24-hour)",day.end());var length=number("Class length (minutes)",day.classMinutes(),15,240);var issue=new Label();issue.getStyleClass().add("error");issue.setWrapText(true);var preview=new FlowPane(6,6);
        Runnable update=()->{var old=project.days.get(index);var d=new SimpleProject.Day(old.name(),true,start.value(),end.value(),length.value(),old.breaks());project.days.set(index,d);String error=SimpleProject.dayError(d);issue.setText(error);preview.getChildren().clear();if(error.isEmpty())for(var p:SimpleProject.periods(d)){var block=new Label(p[2]+"–"+p[3]+"\n"+(p[4].equals("Teaching")?"Teaching":p[1]));block.getStyleClass().add(p[4].equals("Teaching")?"preview-teaching":"preview-break");preview.getChildren().add(block);}changed();};
        start.watch(update);end.watch(update);length.watch(update);
        card.getChildren().addAll(title,new HBox(24,start,end,length),issue);
        var breaks=new VBox(6);for(var b:day.breaks())breaks.getChildren().add(new HBox(12,new Label("Break   "+Data.clock(b.start())+"–"+Data.clock(b.end())),button("Remove break",()->{var old=project.days.get(index);var list=new ArrayList<>(old.breaks());list.remove(b);project.days.set(index,new SimpleProject.Day(old.name(),old.enabled(),old.start(),old.end(),old.classMinutes(),list));changed();render();})));
        card.getChildren().addAll(breaks,new HBox(10,button("Add break",()->breakDialog(index)),button("Copy to other days",()->copyDay(index))),note("Live preview · green = teaching · grey = break / short remainder"),preview);
        String error=SimpleProject.dayError(day);issue.setText(error);if(error.isEmpty())for(var p:SimpleProject.periods(day)){var block=new Label(p[2]+"–"+p[3]+"\n"+(p[4].equals("Teaching")?"Teaching":p[1]));block.getStyleClass().add(p[4].equals("Teaching")?"preview-teaching":"preview-break");preview.getChildren().add(block);}page.getChildren().add(card);
    }
    void breakDialog(int index){
        var d=project.days.get(index);if(!SimpleProject.dayError(d).isEmpty()){pageError.setText("Fix this day’s times before adding another break.");return;}var dialog=new Dialog<ButtonType>();dialog.initOwner(stage);dialog.setTitle("Add break • "+d.name());dialog.getDialogPane().getStylesheets().add(getClass().getResource("/studio.css").toExternalForm());
        var start=new SimpleFields.Time("Break start (24-hour)",Math.min(d.end()-1,d.start()+90));var end=new SimpleFields.Time("Break end (24-hour)",Math.min(d.end(),d.start()+120));var error=new Label();error.getStyleClass().add("error");error.setWrapText(true);
        dialog.getDialogPane().setContent(new VBox(12,start,end,error));dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL,ButtonType.OK);
        Runnable check=()->{var list=new ArrayList<>(d.breaks());list.add(new SimpleProject.Break(start.value(),end.value()));String message=SimpleProject.dayError(new SimpleProject.Day(d.name(),true,d.start(),d.end(),d.classMinutes(),list));error.setText(message);dialog.getDialogPane().lookupButton(ButtonType.OK).setDisable(!message.isEmpty());};start.watch(check);end.watch(check);check.run();
        if(dialog.showAndWait().orElse(ButtonType.CANCEL)==ButtonType.OK){var list=new ArrayList<>(d.breaks());list.add(new SimpleProject.Break(start.value(),end.value()));project.days.set(index,new SimpleProject.Day(d.name(),true,d.start(),d.end(),d.classMinutes(),list));changed();render();}
    }
    void copyDay(int source){
        var d=project.days.get(source);if(!SimpleProject.dayError(d).isEmpty()){pageError.setText("Fix "+d.name()+" before copying.");return;}
        var dialog=new Dialog<ButtonType>();dialog.initOwner(stage);dialog.setTitle("Copy "+d.name()+" times");var choices=new LinkedHashMap<Integer,CheckBox>();var body=new VBox(12,note("Replaces start, end, class length and breaks on selected days. Day selection stays unchanged."));
        for(int i=0;i<project.days.size();i++)if(i!=source){var c=new CheckBox(project.days.get(i).name());c.setTooltip(new Tooltip("Select this day to replace its time settings with "+d.name()+"."));choices.put(i,c);body.getChildren().add(c);}dialog.getDialogPane().setContent(body);dialog.getDialogPane().getStylesheets().add(getClass().getResource("/studio.css").toExternalForm());dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL,ButtonType.OK);
        if(dialog.showAndWait().orElse(ButtonType.CANCEL)==ButtonType.OK){choices.forEach((i,c)->{if(c.isSelected()){var target=project.days.get(i);project.days.set(i,new SimpleProject.Day(target.name(),target.enabled(),d.start(),d.end(),d.classMinutes(),d.breaks()));}});changed();render();}
    }
    void rooms(){
        var t=table(project.rooms,new String[]{"Name (text)","Type","Capacity (int)"},List.of(SimpleProject.Room::name,SimpleProject.Room::type,r->""+r.capacity()));
        page.getChildren().addAll(note("Theory uses a Classroom. Practical teaching uses a Lab. Each subject's own enrollment must fit."),new HBox(10,button("Add room",()->roomDialog(null)),button("Edit selected",()->{var r=t.getSelectionModel().getSelectedItem();if(r!=null)roomDialog(r);}),button("Remove selected",()->{var r=t.getSelectionModel().getSelectedItem();if(r!=null){project.rooms.remove(r);changed();render();}})),t);
    }
    void roomDialog(SimpleProject.Room old){
        var name=text("Room name (text)",old==null?"":old.name(),true);var type=choice("Type",old==null?"Classroom":old.type(),List.of("Classroom","Lab"));var seats=number("Capacity (students)",old==null?40:old.capacity(),1,1000);
        form("Room",List.of(name,type,seats),()->project.rooms.stream().anyMatch(r->r!=old&&r.name().equalsIgnoreCase(name.value()))?"A room with this name already exists.":"",()->{var r=new SimpleProject.Room(name.value(),type.value(),seats.value());if(old==null)project.rooms.add(r);else project.rooms.set(project.rooms.indexOf(old),r);changed();render();});
    }
    void review(){
        page.getChildren().add(note("4 stages • "+project.groups.size()+" groups • "+project.subjects.size()+" subjects • "+project.subjects.stream().mapToInt(SimpleProject.Subject::sessions).sum()+" weekly sessions • "+project.rooms.size()+" rooms"));
        var issues=project.health();if(issues.stream().noneMatch(SimpleProject.Issue::error)){
            try{var m=new ProblemData(project.toData());for(String message:HealthReport.inspect(m))issues.add(new SimpleProject.Issue(true,message.startsWith("Instructor")?2:4,message));}catch(Exception ex){issues.add(new SimpleProject.Issue(true,2,ex.getMessage()));}
        }
        if(issues.isEmpty()){var ready=new Label("Ready to generate. All entered data passed the health checks.");ready.getStyleClass().add("success");page.getChildren().add(ready);}
        for(var issue:issues){var label=new Label(issue.message());label.setWrapText(true);label.getStyleClass().add(issue.error()?"error":"warning");var fix=new Hyperlink("Go fix it → "+steps[issue.step()]);fix.setOnAction(e->{step=issue.step();render();});var box=new VBox(4,label,fix);box.getStyleClass().add("card");page.getChildren().add(box);}
        page.getChildren().add(note("The fixed objective reduces student idle gaps and balances teaching across days. Health checks are necessary checks; only the solver can establish full feasibility."));
    }
    void generation(){
        var advanced=new TitledPane("Advanced • baseline methods",new VBox(12,method,note("CP is the default. Random and Exhaustive are lecture baselines. Seed is fixed at 7; one CP worker. Exhaustive search is intended for tiny examples.")));advanced.setExpanded(false);
        var start=button("Generate timetable",this::generate);start.getStyleClass().add("primary");start.setId("generate");var cancel=button("Cancel",()->{if(task!=null)task.cancel();});cancel.setId("cancel");cancel.setDisable(!busy);
        progress.setMaxWidth(Double.MAX_VALUE);progress.setPrefHeight(8);runStatus.setWrapText(true);
        var options=new VBox(12,new HBox(24,limit,advanced),new HBox(12,start,cancel),progress);
        if(result==null)page.getChildren().add(options);else{var pane=new TitledPane("Generate again • options",options);pane.setExpanded(false);page.getChildren().add(pane);}
        page.getChildren().addAll(runStatus,timetable);
        if(result!=null)draw();else timetable.getChildren().setAll(note("Generate to see all four stages together. Stage, group, room and instructor filters will appear here."));
    }
    void generate(){
        if(busy)return;
        if(project.health().stream().anyMatch(SimpleProject.Issue::error)){step=5;render();pageError.setText("Fix the red errors before generating.");return;}
        autosave.stop();SimpleProject snapshot=SimpleProject.parse(project.json());int seconds=limit.value();String selected=method.value();
        busy=true;fileButtons.forEach(n->n.setDisable(true));sidebar.setDisable(true);back.setDisable(true);limit.setDisable(true);method.setDisable(true);
        root.lookup("#generate").setDisable(true);root.lookup("#cancel").setDisable(false);result=null;timetable.getChildren().setAll(note("Building a weekly timetable…"));long started=System.nanoTime();
        var timer=new Timeline(new KeyFrame(Duration.millis(150),e->{double elapsed=(System.nanoTime()-started)/1e9;progress.setProgress(Math.min(.99,elapsed/seconds));runStatus.setText("Running "+selected+" • "+String.format(Locale.ROOT,"%.1f",elapsed)+" seconds • best score: "+(live==null||live.best==null?"searching":live.score));}));timer.setCycleCount(Animation.INDEFINITE);
        task=new Task<>(){protected SearchEngine call(){var m=new ProblemData(snapshot.toData());var search=new SearchEngine(m,new SearchEngine.Settings(7,seconds,16,100,.12,Long.MAX_VALUE),this::isCancelled);live=search;search.run(selected,new ConstraintSearch());return search;}};
        Runnable finish=()->{timer.stop();busy=false;live=null;fileButtons.forEach(n->n.setDisable(false));sidebar.setDisable(false);back.setDisable(false);limit.setDisable(false);method.setDisable(false);root.lookup("#generate").setDisable(false);root.lookup("#cancel").setDisable(true);progress.setProgress(1);};
        task.setOnSucceeded(e->{finish.run();result=task.getValue();runStatus.setText(result.status+" • "+String.format(Locale.ROOT,"%.2f",(System.nanoTime()-started)/1e9)+" seconds"+(result.best==null?"":" • zero hard violations • score "+result.score));if(result.best!=null){if(!Evaluator.evaluate(result.m,result.best).valid())throw new IllegalStateException("Independent evaluator rejected a result");configureFilters();render();status.setText("Timetable generated • inputs "+(dirty?"not saved to a named file":"saved"));}else timetable.getChildren().setAll(note(result.status.equals("UNKNOWN")?"No feasible timetable was found within this time limit. Try a longer limit; UNKNOWN does not mean impossible.":result.status));task=null;});
        task.setOnCancelled(e->{finish.run();runStatus.setText("Cancelled. You can edit the inputs or generate again.");task=null;});
        task.setOnFailed(e->{finish.run();task.getException().printStackTrace();runStatus.setText("Could not generate: "+Objects.toString(task.getException().getMessage(),task.getException().toString()));task=null;});timer.play();new Thread(task,"simple-timetable-solver").start();
    }
    void configureFilters(){
        for(var f:List.of(stageFilter,groupFilter,roomFilter,teacherFilter)){f.setOnAction(null);f.getItems().setAll("All");f.setValue("All");}
        for(int s=1;s<=4;s++)stageFilter.getItems().add("Stage "+s);project.groups.forEach(g->groupFilter.getItems().add(g.id()));project.rooms.forEach(r->roomFilter.getItems().add(r.name()));project.subjects.stream().map(SimpleProject.Subject::instructor).filter(s->!s.isBlank()).distinct().sorted().forEach(teacherFilter.getItems()::add);
        for(var f:List.of(stageFilter,groupFilter,roomFilter,teacherFilter))f.setOnAction(e->draw());
    }
    boolean visible(int index){var e=result.m.events.get(index);var p=result.m.choices.get(index).get(result.best[index]);return (stageFilter.getValue().equals("All")||e.groups().stream().anyMatch(g->result.m.stages.get(g).equals(stageFilter.getValue())))&&(groupFilter.getValue().equals("All")||e.groups().contains(groupFilter.getValue()))&&(roomFilter.getValue().equals("All")||roomFilter.getValue().equals(p.room()))&&(teacherFilter.getValue().equals("All")||teacherFilter.getValue().equals(e.teacher()));}
    void draw(){
        if(result==null||result.best==null)return;timetable.getChildren().clear();visibleRows.clear();
        var filters=new FlowPane(16,10);String[] labels={"Stage","Group","Room","Instructor"};var fields=List.of(stageFilter,groupFilter,roomFilter,teacherFilter);
        for(int i=0;i<4;i++){var f=fields.get(i);f.setPrefWidth(170);f.setTooltip(new Tooltip("Filter by "+labels[i].toLowerCase(Locale.ROOT)+", or All."));filters.getChildren().add(new VBox(4,new Label(labels[i]),f));}
        timetable.getChildren().addAll(new Separator(),filters,new HBox(10,button("Export printable HTML",()->export(true)),button("Export visible CSV",()->export(false))),note("Theory = mint · Lab = teal/lime · Breaks = grey. All four stages share rooms and instructors."));
        var grid=new GridPane();grid.setHgap(2);grid.setVgap(2);var shownGroups=result.m.stages.keySet().stream().filter(g->stageFilter.getValue().equals("All")||result.m.stages.get(g).equals(stageFilter.getValue())).filter(g->groupFilter.getValue().equals("All")||g.equals(groupFilter.getValue())).toList();
        var layout=new WeekGrid(result.m.data,result,shownGroups);double columnWidth=Math.min(240,Math.max(116,875.0/Math.max(1,shownGroups.size())));
        grid.getColumnConstraints().add(new ColumnConstraints(85));grid.getColumnConstraints().add(new ColumnConstraints(60));
        for(int i=0;i<shownGroups.size();i++)grid.getColumnConstraints().add(new ColumnConstraints(columnWidth));
        for(var c:layout.cells){if(c.event()>=0&&!visible(c.event()))continue;var label=new Label(c.text());label.setWrapText(true);label.setMinWidth(0);label.setPrefWidth(c.col()==0?85:c.col()==1?60:columnWidth*c.width());label.setMaxSize(Double.MAX_VALUE,Double.MAX_VALUE);label.getStyleClass().addAll("sheet-cell",c.style());grid.add(label,c.col(),c.row(),c.width(),c.height());if(c.event()>=0){String detail=c.text().replace('\n',' ');label.setTooltip(new Tooltip(detail));label.setOnMouseClicked(e->gridDetail.setText(detail));}}
        var scroll=new ScrollPane(grid);scroll.setPrefViewportHeight(430);scroll.setMinHeight(260);scroll.setPannable(true);timetable.getChildren().addAll(scroll,gridDetail);
        for(int i=0;i<result.best.length;i++)if(visible(i)){var e=result.m.events.get(i);var p=result.m.choices.get(i).get(result.best[i]);visibleRows.add(new String[]{p.day(),Data.clock(p.start()),Data.clock(p.start()+e.span()),e.name(),e.teacher().startsWith("__unassigned_")?"":e.teacher(),String.join(",",e.groups()),p.room()});}
        var score=Evaluator.evaluate(result.m,result.best);int gaps=score.gaps().stream().mapToInt(Evaluator.Gap::minutes).sum();long balance=Objectives.breakdown(result.m,result.best,gaps)[2];timetable.getChildren().add(note("Student idle gaps: "+gaps+" minutes • daily balance penalty: "+balance+" • total: "+result.score+". A feasible result is not necessarily optimal."));
    }
    void export(boolean html){var chooser=new FileChooser();chooser.setInitialFileName(html?"Department-Timetable.html":"Department-Timetable.csv");var f=chooser.showSaveDialog(stage);if(f==null)return;try{if(html)SheetExport.save(result.m.data,result,f.toPath());else SimpleExport.csv(f.toPath(),visibleRows);status.setText("Exported "+f.getName());}catch(Exception ex){showError(ex);}}
    public static void main(String[] args){launch(args);}
}
