package edu.timetable;
import java.util.*;
import java.util.function.*;
class SearchEngine implements SearchMethod {
    static final org.slf4j.Logger LOG=org.slf4j.LoggerFactory.getLogger(SearchEngine.class);
    record Settings(int seed,double seconds,int population,int generations,double mutation,long samples){
        Settings{ProblemData.require(seconds>0&&Double.isFinite(seconds)&&population>=2&&generations>0&&mutation>=0&&mutation<=1&&samples>0,"Invalid search settings");}
    }
    interface ConstraintSolver {int[] solve(SearchEngine run,int[] child,boolean optimize,double seconds);}
    final ProblemData m;final Settings settings;final Random rng;final BooleanSupplier cancelled;final long start;
    long evaluations;volatile int[] best;volatile int score=Integer.MAX_VALUE;String status="Budget ended";boolean proved;
    final List<double[]> trace=new ArrayList<>();
    SearchEngine(ProblemData model,Settings options,BooleanSupplier cancel){m=model;settings=options;rng=new Random(options.seed);cancelled=cancel;start=System.nanoTime();}
    double elapsed(){return (System.nanoTime()-start)/1e9;}
    double left(){return settings.seconds-elapsed();}
    boolean stop(){return left()<=0||cancelled.getAsBoolean();}
    int inspect(int[] genes){
        evaluations++;var result=new DefaultEvaluator().evaluate(m,new Candidate(genes));
        if(!result.feasible())return Integer.MAX_VALUE;
        if(result.objective()<score){best=genes.clone();score=result.objective();trace.add(new double[]{evaluations,score,elapsed()});}
        return result.objective();
    }
    int[] sample(){int[] genes=new int[m.events.size()];for(int i=0;i<genes.length;i++)genes[i]=rng.nextInt(m.choices.get(i).size());return genes;}
    public void run(String method,ConstraintSolver cp){
        LOG.debug("Starting {} seed={} budget={}",method,settings.seed,settings.seconds);
        for(int i=0;i<m.events.size();i++)if(m.choices.get(i).isEmpty()){
            var e=m.events.get(i);status="INFEASIBLE: "+m.diagnostics.get(i);return;}
        switch(method){
            case "Random"->{while(!stop()&&evaluations<settings.samples)inspect(sample());}
            case "Exhaustive"->{proved=enumerate(new int[m.events.size()],0);}
            case "CP"->{int[] result=cp.solve(this,null,true,left());if(result!=null)inspect(result);}
            case "GA"->evolve(cp);
            case "Hybrid"->lns(cp);
            default->throw new IllegalArgumentException(method);
        }
        if(cancelled.getAsBoolean())status="Cancelled";
        else if(best!=null)status=proved||score==0?"OPTIMAL":"FEASIBLE";
        else if(proved)status="INFEASIBLE";
        else status="UNKNOWN";
        LOG.debug("Finished {} status={} score={} seconds={}",method,status,score,elapsed());
    }
    void lns(ConstraintSolver cp){
        int[] seed=cp.solve(this,null,false,Math.min(left(),Math.max(.2,settings.seconds/3)));
        if(seed==null)return;inspect(seed);
        for(int i=0;i<settings.generations&&!stop()&&score>0;i++){
            int[] improved=cp.solve(this,best.clone(),true,Math.min(left(),Math.max(.2,settings.seconds/10)));
            if(improved!=null)inspect(improved);
        }
    }
    boolean enumerate(int[] genes,int i){
        if(stop())return false;
        if(i==genes.length){inspect(genes);return true;}
        for(int j=0;j<m.choices.get(i).size();j++){genes[i]=j;if(!enumerate(genes,i+1))return false;}
        return true;
    }
    record Member(int[] genes,int cost){}
    Member tournament(List<Member> population){
        Member winner=population.get(rng.nextInt(population.size()));
        for(int i=1;i<3;i++){Member rival=population.get(rng.nextInt(population.size()));if(rival.cost<winner.cost)winner=rival;}
        return winner;
    }
    int[] crossover(Member a,Member b){int[] child=a.genes.clone();for(int i=0;i<child.length;i++)if(rng.nextBoolean())child[i]=b.genes[i];return child;}
    void mutate(int[] child){for(int i=0;i<child.length;i++)if(rng.nextDouble()<settings.mutation)child[i]=rng.nextInt(m.choices.get(i).size());}
    void evolve(ConstraintSolver cp){
        var population=new ArrayList<Member>();
        for(int i=0;i<Math.min(4,settings.population)&&!stop();i++){
            int[] seed=cp.solve(this,null,false,Math.min(left(),Math.max(.2,settings.seconds/5)));
            if(seed!=null){int cost=inspect(seed);if(cost!=Integer.MAX_VALUE)population.add(new Member(seed,cost));}
            if(proved||score==0)return;
        }
        if(population.isEmpty())return;
        while(population.size()<settings.population)population.add(population.get(rng.nextInt(population.size())));
        for(int g=0;g<settings.generations&&!stop()&&score>0;g++){
            var next=new ArrayList<Member>();next.add(new Member(best.clone(),score));
            while(next.size()<settings.population&&!stop()){
                Member parent=tournament(population);int[] child=crossover(parent,tournament(population));mutate(child);
                int cost=inspect(child);
                if(cost==Integer.MAX_VALUE){child=cp.solve(this,child,false,Math.min(.3,left()));if(child!=null)cost=inspect(child);}
                next.add(cost<Integer.MAX_VALUE?new Member(child,cost):parent);
            }
            population=next;
        }
    }
}
