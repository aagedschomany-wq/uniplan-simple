package edu.timetable;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class SimpleProjectTest {
    @TempDir Path temp;
    @Test void demoIsFourStagesAndAllResources(){var p=SimpleProject.demo();assertTrue(p.health().isEmpty());var m=new ProblemData(p.toData());assertEquals(56,m.events.size());assertEquals(8,m.stages.size());assertEquals(14,p.rooms.size());assertEquals(5,m.days.size());assertTrue(m.choices.stream().noneMatch(List::isEmpty));assertEquals(0,p.toData().rows.get("Term").size());}
    @Test void everyChoiceFitsAClassPeriodAndNeverABreak(){
        var p=SimpleProject.demo();var m=new ProblemData(p.toData());
        for(int i=0;i<m.events.size();i++)for(var choice:m.choices.get(i)){
            var e=m.events.get(i);var day=p.days.stream().filter(d->d.name().equals(choice.day())).findFirst().orElseThrow();
            assertTrue(SimpleProject.periods(day).stream().anyMatch(r->r[4].equals("Teaching")&&Data.minute(r[2])<=choice.start()&&choice.start()+e.span()<=Data.minute(r[3])));
            assertTrue(day.breaks().stream().noneMatch(b->ProblemData.overlap(choice.start(),choice.start()+e.span(),b.start(),b.end())));
        }
    }
    @Test void independentDaysAndPartialRemainder(){
        var d=new SimpleProject.Day("Monday",true,480,780,90,List.of(new SimpleProject.Break(570,600)));
        var periods=SimpleProject.periods(d);assertEquals(4,periods.size());assertEquals("08:00",periods.getFirst()[2]);assertEquals("Required break",periods.get(1)[4]);
        var e=new SimpleProject.Day("Sunday",true,540,750,90,List.of());assertEquals("Unavailable",SimpleProject.periods(e).getLast()[4]);
        assertFalse(SimpleProject.dayError(new SimpleProject.Day("Sunday",true,540,500,90,List.of())).isEmpty());
        assertFalse(SimpleProject.dayError(new SimpleProject.Day("Sunday",true,540,900,90,List.of(new SimpleProject.Break(550,600),new SimpleProject.Break(590,610)))).isEmpty());
    }
    @Test void optionalTeachersAreIndependentAndNamedTeachersShareAResource(){
        var p=SimpleProject.demo();p.subjects.replaceAll(s->new SimpleProject.Subject(s.id(),s.stage(),s.group(),s.name(),s.type(),s.students(),s.sessions(),s.minutes(),""));
        var d=p.toData();assertEquals(56,d.rows.get("Teachers").size());assertTrue(p.health().stream().allMatch(i->!i.error()));
        var first=p.subjects.getFirst();p.subjects.set(0,new SimpleProject.Subject(first.id(),first.stage(),first.group(),first.name(),first.type(),first.students(),2,first.minutes(),"Shared"));
        var second=p.subjects.get(7);p.subjects.set(7,new SimpleProject.Subject(second.id(),second.stage(),second.group(),second.name(),second.type(),second.students(),1,second.minutes(),"Shared"));
        var m=new ProblemData(p.toData());assertEquals(57,m.events.size());assertNotNull(m.conflict(0,new ProblemData.Time("Sunday",540,"Classroom 1"),8,new ProblemData.Time("Sunday",540,"Classroom 2")));
    }
    @Test void healthReportsCapacityAndLongSubject(){
        var p=SimpleProject.demo();var s=p.subjects.getFirst();p.subjects.set(0,new SimpleProject.Subject(s.id(),s.stage(),s.group(),"Oversized",s.type(),70,1,120,s.instructor()));
        assertTrue(p.health().stream().anyMatch(i->i.error()&&i.step()==4&&i.message().contains("70")&&i.message().contains("60")));
        assertTrue(p.health().stream().anyMatch(i->i.error()&&i.step()==3&&i.message().contains("120")));
        assertThrows(IllegalArgumentException.class,p::toData);
    }
    @Test void jsonRoundTripUnicodePipesAndSchema()throws Exception{
        var p=SimpleProject.demo();p.university="زانکۆ | جامعة";var file=temp.resolve("project.json");p.save(file);var copy=SimpleProject.load(file);assertEquals(p.json(),copy.json());
        assertThrows(IllegalArgumentException.class,()->SimpleProject.parse(p.json().replace("\"schemaVersion\": 1","\"schemaVersion\": 99")));
        p.save(file);assertEquals(56,SimpleProject.load(file).subjects.size());
    }
    @Test void fixedWeightsAndSimpleCpAgreement(){
        var p=SimpleProject.demo();p.subjects=new ArrayList<>(p.subjects.subList(0,2));var m=new ProblemData(p.toData());assertArrayEquals(new int[]{1,0,1,0,0,0,0,0,0},Objectives.weights(m));
        var cp=new SearchEngine(m,new SearchEngine.Settings(7,5,16,10,.1,1000),()->false);cp.run("CP",new ConstraintSearch());assertNotNull(cp.best);assertTrue(Evaluator.evaluate(m,cp.best).valid());
        assertEquals(Evaluator.evaluate(m,cp.best).minutes(),cp.score);
    }
    @Test void exportsEscapeTextAndUseGreenPalette()throws Exception{
        var file=temp.resolve("out.csv");SimpleExport.csv(file,List.<String[]>of(new String[]{"Sunday","09:00","10:30","A, B \"C\"","دکتۆر","1 A","Room | 1"}));assertTrue(Files.readString(file).contains("\"A, B \"\"C\"\"\""));
        String css=SimpleExport.htmlCss();assertTrue(css.contains("--primary:#1F8A5B"));assertFalse(css.contains("#15253c"));
    }
}
